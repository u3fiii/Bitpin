import "./styles/app.scss";

import Homepage from "./pages/Homepage";
function App() {
  return (
    <div className="App">
      <Homepage />
    </div>
  );
}

export default App;
