import Advertisements from "./Advertisements";
function App() {
  return (
    <div className="App">
      This is app
      <Advertisements />
    </div>
  );
}

export default App;
